
Bold/ **** = Done

Components - 
Nav
  NavCSS
Footer
  FooterCSS

Home
  **Nav**
  **Hero**
  **Important Link**
  **Mission**
  **NewsLetter/Updates**
  **Footer**
About US
  **Nav**
  **Footer**
Our Work
  **Nav**
  **Footer**
Projects
  **Nav**
  **Footer**
Documents
  **Nav**
  **Footer**
Donate
  **Nav**
  **Footer**