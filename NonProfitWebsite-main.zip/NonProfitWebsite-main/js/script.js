// Show content once page loads
window.addEventListener('load', function() {

  // Hide loading overlay
  document.getElementById('loading').style.display = 'none';
})

